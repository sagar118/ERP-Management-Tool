HOST = "localhost"
DATABASE = "DMQL_Project"
USER = "postgres"
PASSWORD = "PostgreSQL#118"